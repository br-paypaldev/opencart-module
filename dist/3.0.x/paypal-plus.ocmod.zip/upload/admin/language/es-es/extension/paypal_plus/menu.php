<?php
// Text
$_['text_paypal_plus']             = 'PayPal Plus';
$_['text_paypal_plus_transaction'] = 'Transacciones';
$_['text_paypal_plus_log']         = 'Registros';
