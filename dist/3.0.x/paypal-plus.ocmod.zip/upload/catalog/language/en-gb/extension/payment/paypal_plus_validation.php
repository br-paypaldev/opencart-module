<?php
// Error
$_['error_customer']          = '- Nome completo.<br>';
$_['error_document']          = '- CPF.<br>';
$_['error_telephone']         = '- Telefone.<br>';
$_['error_payment_postcode']  = '- CEP do endereço.<br>';
$_['error_payment_address']   = '- Endereço completo.<br>';
$_['error_payment_number']    = '- Número do endereço.<br>';
$_['error_payment_address_2'] = '- Bairro do endereço.<br>';
$_['error_payment_city']      = '- Cidade do endereço.<br>';
$_['error_payment_zone_code'] = '- Estado do endereço.<br>';
