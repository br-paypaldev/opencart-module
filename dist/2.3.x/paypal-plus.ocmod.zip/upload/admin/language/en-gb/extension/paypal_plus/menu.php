<?php
// Text
$_['text_paypal_plus']             = 'PayPal Plus';
$_['text_paypal_plus_transaction'] = 'Transações';
$_['text_paypal_plus_log']         = 'Log de informações';
