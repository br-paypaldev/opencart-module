<?php
// Error
$_['error_customer']          = '- Nombre completo.<br>';
$_['error_document']          = '- CPF.<br>';
$_['error_telephone']         = '- Teléfono.<br>';
$_['error_payment_postcode']  = '- Código postal.<br>';
$_['error_payment_address']   = '- Direccion.<br>';
$_['error_payment_number']    = '- Número de dirección.<br>';
$_['error_payment_address_2'] = '- Dirección 2.<br>';
$_['error_payment_city']      = '- Ciudad.<br>';
$_['error_payment_zone_code'] = '- Region / Provincia.<br>';
